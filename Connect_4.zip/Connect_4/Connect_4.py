# JAKUB TOMA
# ROCNIKOVY PROJEKT 1

import pygame
from pygame.locals import * #pre moznosti typu QUIT()
import random #pri vybere prveho hraca a pri nahodnom hode AI
import sys #na moznost vypnutia hry
import copy #na vytvorenie kopie tabulky pomocou copy.deepcopy()


class Game:
    def __init__(self):
        pygame.init()
        
        #Velkosti
        
        #POCET RIADKOV = 6
        #POCET STLPCOV = 7
        
        self.SPACESIZE = 75
        self.MOVE_BOARD_RIGHT = 0
        self.MOVE_BOARD_DOWN = 25

        self.WINDOW_WIDTH = 1024
        self.WINDOW_HEIGHT = 768
        self.FPS = 30

        #rychlost tokenov < 1.0 - 100.0>
        self.DROP_SPEED = 10.0
        self.PC_SPEED = 10.0
        
        #Okraje tabulky
        self.MARGIN_X = int((self.WINDOW_WIDTH - 7 * self.SPACESIZE) / 2) + self.MOVE_BOARD_RIGHT
        self.MARGIN_Y = int((self.WINDOW_HEIGHT - 6 * self.SPACESIZE) / 2) + self.MOVE_BOARD_DOWN
        
        self.WINDOW = pygame.Rect(0, 0, self.SPACESIZE, self.SPACESIZE) #okno v tabulke
        self.TOKEN1 = '1'
        self.TOKEN2 = '2'
        self.PLAYER = 'PLAYER'
        self.PC = 'PC'
        self.FPS = 30
        self.NAME = 'Jakub' #meno hraca

        #znacka win / lose / tie
        self.SIGN_POS = (-50,25)
        self.SIGN_SIZE = (400,600)

        STACK_MOVE_UP = 0#75
        STACK_MOVE_CENTER = 0#125
        
        self.TOKEN1_STACK = pygame.Rect(int(self.SPACESIZE / 2) + STACK_MOVE_CENTER, self.WINDOW_HEIGHT - int(
            3 * self.SPACESIZE / 2) - STACK_MOVE_CENTER, self.SPACESIZE, self.SPACESIZE)
        self.TOKEN2_STACK = pygame.Rect(self.WINDOW_WIDTH - int(3 * self.SPACESIZE / 2) -STACK_MOVE_CENTER,  self.WINDOW_HEIGHT - int(
            3 * self.SPACESIZE / 2) - STACK_MOVE_CENTER, self.SPACESIZE, self.SPACESIZE)
    
        #do akej hlbky pozerame <2 je optimalne, 3 uz trva dlhsie>
        self.DEEP = 2
        
        #obrazky
        self.TOKEN1_IMG = pygame.image.load('pictures/tokens/token_type1.png')
        self.TOKEN2_IMG = pygame.image.load('pictures/tokens/token_type3.png')
        self.WINDOW_IMG = pygame.image.load('pictures/windows/window_type1.png')

        #znacka
        self.PCWON_IMG = pygame.image.load('pictures/sign/lose.png')
        self.PLAYERWON_IMG = pygame.image.load('pictures/sign/win.png')
        self.TIE_IMG = pygame.image.load('pictures/sign/tie.png')

        #zmena velkosti obrazkov na velkost medzier
        self.TOKEN1_IMG = pygame.transform.smoothscale(self.TOKEN1_IMG, (self.SPACESIZE, self.SPACESIZE))
        self.TOKEN2_IMG = pygame.transform.smoothscale(self.TOKEN2_IMG, (self.SPACESIZE, self.SPACESIZE))
        self.WINDOW_IMG = pygame.transform.smoothscale(self.WINDOW_IMG, (self.SPACESIZE, self.SPACESIZE))

        #Pocet obrazkov za sek. => FPS
        self.FPS = pygame.time.Clock()
        
        #Obrazovka
        self.SCREEN = pygame.display.set_mode((self.WINDOW_WIDTH,self.WINDOW_HEIGHT))
        pygame.display.set_caption("Connect 4")

        #Pozadie
        self.BG = pygame.image.load('pictures/backgrounds/background1.jpg')
        self.SCREEN.blit(self.BG, (0, 0))

        #Highscore
        self.MOVES_COUNT_PLAYER = 0
        self.MOVES_COUNT_PC = 0


        END_GAME = False
        while not END_GAME:
            self.run_game()
            

    def run_game(self):
        #zacina sa nahodne
        if random.randint(0, 1) == 1:
            onMove = self.PLAYER
        else:
            onMove = self.PC
            
        GameBoard = self.create_board()
        
        while True:
            if onMove == self.PLAYER:
                #Ja som na tahu
                self.PlayerMove(GameBoard)
                self.MOVES_COUNT_PLAYER += 1
                if self.isWinner(GameBoard, self.TOKEN1):
                    #Zapis do HS
                    self.TO_WRITE = self.NAME+','+ str(self.MOVES_COUNT_PLAYER)+'\n'
                    with open("highscore.txt",'a')as file:
                        file.write(self.TO_WRITE)
                    win_img = self.PLAYERWON_IMG
                    break
                
                onMove = self.PC
                
            else:
                #PC na tahu
                column = self.PcMove(GameBoard)
                self.PC_move_animation(GameBoard, column)
                self.makeMove(GameBoard, self.TOKEN2, column)
                self.MOVES_COUNT_PC += 1
                if self.isWinner(GameBoard, self.TOKEN2):
                    #zapis do HS
                    self.TO_WRITE = 'PC, '+str(self.MOVES_COUNT_PC)+'\n'
                    with open("highscore.txt",'a')as file:
                        file.write(self.TO_WRITE)
                    win_img = self.PCWON_IMG  
                    break
                
                onMove = self.PLAYER

            if self.isFull(GameBoard):
                #REMIZA
                win_img = self.TIE_IMG
                break

        while True:
            # hra bezi stale
            self.draw_board(GameBoard)
            win_img = pygame.transform.smoothscale(win_img, self.SIGN_SIZE)
            self.SCREEN.blit(win_img, self.SIGN_POS)
            pygame.display.update()
            self.FPS.tick()
            
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYUP and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                    
                elif event.type == MOUSEBUTTONUP:
                    Menu()

    def draw_board(self, board, extraToken=None):
        #obnovenie plochy a prekrytie pohybu tokenu (den som nevedel na to prist :D)
        self.SCREEN.blit(self.BG, (0, 0))

        #vykreslenie tokenu v okne
        for x in range(7):
            for y in range(6):
                self.WINDOW.topleft = (self.MARGIN_X + (x * self.SPACESIZE), self.MARGIN_Y + (y * self.SPACESIZE))
                if board[x][y] == self.TOKEN1:
                    self.SCREEN.blit(self.TOKEN1_IMG, self.WINDOW)
                elif board[x][y] == self.TOKEN2:
                    self.SCREEN.blit(self.TOKEN2_IMG, self.WINDOW)

        # token navyse
        if extraToken != None:
            if extraToken['number'] == self.TOKEN1:
                self.SCREEN.blit(self.TOKEN1_IMG, (extraToken['x'], extraToken['y'], self.SPACESIZE, self.SPACESIZE))
                
            elif extraToken['number'] == self.TOKEN2:
                self.SCREEN.blit(self.TOKEN2_IMG, (extraToken['x'], extraToken['y'], self.SPACESIZE, self.SPACESIZE))

        # vykreslenie hracej plochy
        for x in range(7):
            for y in range(6):
                self.WINDOW.topleft = (self.MARGIN_X + (x * self.SPACESIZE), self.MARGIN_Y + (y * self.SPACESIZE))
                self.SCREEN.blit(self.WINDOW_IMG, self.WINDOW)

        # stlpce s tokenmi po stranach
        self.SCREEN.blit(self.TOKEN1_IMG, self.TOKEN1_STACK)
        self.SCREEN.blit(self.TOKEN2_IMG, self.TOKEN2_STACK)


    def create_board(self):
        #vytvorenie prazdnej tabulky
        board = []
        for x in range(7):
            board.append([None] * 6)
        return board

    def makeMove(self, board, which_token, column):
        #vlozi token do tabulky
        lowest_window = self.get_NonEmpty(board, column)
        if lowest_window != -1:
            board[column][lowest_window] = which_token

    
    def valid_move(self, board, column):
        #sleduje ci je dany tah mozny / stlpec nieje plny
        if column < 0 or column >= (7) or board[column][0] != None:
            return False
        return True


    def get_NonEmpty(self, board, column):
        #vrati najnizsi neprazdny riadok v stlpci
        for y in range(5, -1, -1):
            if board[column][y] == None:
                return y
        return -1

    def isFull(self,board):
        #ak je tabulka plna vrati True inak False
        for x in range(7):
            for y in range(6):
                if board[x][y] == None:
                    return False
        return True

    def PlayerMove(self, board):
        #tah hraca
        inMotionToken = False #token pri pohybe
        token_x, token_y = None, None
        while True:
            for event in pygame.event.get():
                
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                    
                elif event.type == MOUSEBUTTONDOWN and self.TOKEN1_STACK.collidepoint(event.pos) and not inMotionToken:
                    # uchopenie tokenu
                    inMotionToken = True
                    token_x, token_y = event.pos
                    
                elif event.type == MOUSEMOTION and inMotionToken:
                    # zmena pozicie pri pohybe tokenu
                    token_x, token_y = event.pos

                elif event.type == MOUSEBUTTONUP and inMotionToken:
                    # pustenie tokenu
                    
                    if token_y < self.MARGIN_Y and token_x > self.MARGIN_X and token_x < self.WINDOW_WIDTH - self.MARGIN_X:
                        # pustenie tokenu kdekolvek nad stlpcom
                        column = int((token_x - self.MARGIN_X) / self.SPACESIZE)
                        if self.valid_move(board, column):
                            self.drop_animation(board, column, self.TOKEN1) #animacia padania
                            board[column][self.get_NonEmpty(board, column)] = self.TOKEN1 #priradanie do tabulky
                            self.draw_board(board) #vykreslenie tabulky
                            pygame.display.update()
                            return
                    #obnovenie patametrov
                    token_x, token_y = None, None
                    inMotionToken = False
                    
                    
            if token_x != None and token_y != None:
                self.draw_board(board, {'x':token_x - int(self.SPACESIZE / 2), 'y':token_y - int(self.SPACESIZE / 2), 'number':self.TOKEN1})
            else:
                self.draw_board(board)

            pygame.display.update()
            self.FPS.tick()

    def isWinner(self, board, token):
        #PODMIENKY VITAZSTVA

        # 4 v riadku --
        for x in range(4):
            for y in range(6):
                if board[x][y] == token and board[x+1][y
                ] == token and board[x+2][y
                ] == token and board[x+3][y] == token:
                    return True
        
        # 4 v stlpci |
        for x in range(7):
            for y in range(3):
                if board[x][y] == token and board[x][y+1
                ] == token and board[x][y+2
                ] == token and board[x][y+3] == token:
                    return True

        # 4 po diagonale smerom \
        for x in range(4):
            for y in range(3):
                if board[x][y] == token and board[x+1][y+1
                ] == token and board[x+2][y+2
                ] == token and board[x+3][y+3] == token:
                    return True


        # 4 po diagonale smerom /
        for x in range(4):
            for y in range(3,6):
                if board[x][y] == token and board[x+1][y-1
                ] == token and board[x+2][y-2
                ] == token and board[x+3][y-3] == token:
                    return True
    

    def drop_animation(self, board, column, number):
        #animacia padania tokenu
        x = self.MARGIN_X + column * self.SPACESIZE
        y = self.MARGIN_Y - self.SPACESIZE
        speed = self.DROP_SPEED
        
        lowest_window = self.get_NonEmpty(board, column)

        while True:
            #vykreslovanie pohybu tokenu kazdym tiknutim FPS
            y += int(speed)
            speed += 0.5
            if int((y - self.MARGIN_Y) / self.SPACESIZE) >= lowest_window:
                return
            
            self.draw_board(board, {'x':x, 'y':y, 'number':number})
            pygame.display.update()
            self.FPS.tick()

    def PcMove(self,board):
        #PC vybera najlepsi tah 
        potentialMoves = self.getMoves(board, self.TOKEN2, self.DEEP)
        bestMove = -1
        for i in range(7):
            if potentialMoves[i] > bestMove and self.valid_move(board, i):
                bestMove = potentialMoves[i]

        bestMoves = []
        for i in range(len(potentialMoves)):
            if potentialMoves[i] == bestMove and self.valid_move(board, i):
                bestMoves.append(i)
                
        #inak  vykona nahodny vyber
        return random.choice(bestMoves)

    def getMoves(self, board, token, deep):
        #vytvori zoznam moznych tahov
        if deep == 0 or self.isFull(board):
            return [0] * 7

        if token == self.TOKEN1:
            enemy = self.TOKEN2 
        else:
            enemy = self.TOKEN1

        # Vyberie ten najlepsi zo zoznamu
        potentialMoves = [0] * 7
        for firstMove in range(7):
            board_copy1 = copy.deepcopy(board)
            if not self.valid_move(board_copy1, firstMove):
                continue
            self.makeMove(board_copy1, token, firstMove)
            
            if self.isWinner(board_copy1, token):
                # vitazstvo ma najvacsiu prioritu a ten vyberie
                potentialMoves[firstMove] = 1
                break
            else:
                # dalej prezera tahy na prekazenie
                if self.isFull(board_copy1):
                    potentialMoves[firstMove] = 0
                else:
                    for counterMove in range(7):
                        board_copy2 = copy.deepcopy(board_copy1)
                        if self.valid_move(board_copy2, counterMove) == False:
                            continue
                        self.makeMove(board_copy2, enemy, counterMove)
                        
                        if self.isWinner(board_copy2, enemy):
                            # prehra ma najnizsiu prioritu
                            potentialMoves[firstMove] = -1
                            break
                        else:
                            # rekurznivne sa vnori do dalsej urovne a postup zopakuje
                            results = self.getMoves(board_copy2, token, deep - 1)
                            potentialMoves[firstMove] += (sum(results) / 7) / 7
        return potentialMoves

    def PC_move_animation(self, board, column):
        #animacia pohybu
        x = self.TOKEN2_STACK.left
        y = self.TOKEN2_STACK.top
        speed = self.PC_SPEED
        
        # pohyb tokenu nahor
        while y > (self.MARGIN_Y - self.SPACESIZE):
            y -= int(speed)
            speed += 0.5
            self.draw_board(board, {'x':x, 'y':y, 'number':self.TOKEN2})
            pygame.display.update()
            self.FPS.tick()
            
        # pohyb tokenu do strany
        
        y = self.MARGIN_Y - self.SPACESIZE
        speed = self.PC_SPEED
        while x > (self.MARGIN_X + column * self.SPACESIZE):
            x -= int(speed)
            speed += 0.5
            self.draw_board(board, {'x':x, 'y':y, 'number':self.TOKEN2})
            pygame.display.update()
            self.FPS.tick()
        #ak bude token nad zvolenym stlpcom, vykona sa pustenie
        self.drop_animation(board, column, self.TOKEN2)

    
class Menu:
    
    def __init__(self):
        pygame.init()
        WIDTH = 500
        HEIGHT = 700
        self.SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Connect 4 Menu")

        IMG_MENU = pygame.image.load('pictures/menu/menu.png')
        IMG_BUTTON_NEW_GAME = pygame.image.load('pictures/menu/button1.jpg')
        IMG_BUTTON_INFO = pygame.image.load('pictures/menu/button2.jpg')
        IMG_HIGHSCORE = pygame.image.load('pictures/menu/button_hs.png')
        IMG_BUTTON_EXIT = pygame.image.load('pictures/menu/button3.jpg')
        IMG_BEEHIVE = pygame.image.load('pictures/menu/beehive.png')

        #soundtrack YOU BELONG TO ME
        SOUNDTRACK = pygame.mixer.music.load('sounds/soundtrack.wav')
        pygame.mixer.music.play(-1)

        self.SCREEN.fill((255,255,255))
        self.SCREEN.blit(IMG_BEEHIVE, (150, 100))
        self.SCREEN.blit(IMG_MENU, (50, 0))
        self.SCREEN.blit(IMG_BUTTON_NEW_GAME, (150, 275))
        self.SCREEN.blit(IMG_BUTTON_INFO, (150, 375))
        self.SCREEN.blit(IMG_HIGHSCORE, (150, 475))
        self.SCREEN.blit(IMG_BUTTON_EXIT, (150, 575))
        pygame.display.update()

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                    if x >= 160 and x <= 360:
                        if y >= 280 and y <= 340:
                            Game()
                        elif y >= 380 and y <= 440:
                            Info()
                        elif y >= 480 and y <= 540:
                            Highscore()
                        elif y >= 580 and y <= 640:
                            pygame.quit()
                            sys.exit()
        pygame.quit()

class Info:
    
    def __init__(self):
        pygame.init()
        WIDTH = 500
        HEIGHT = 700
        self.SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Connect 4 Navod")

        IMG_NAVOD = pygame.image.load('pictures/menu/navod.png')
        IMG_BACK = pygame.image.load('pictures/menu/navrat.png')
        IMG_BEES = pygame.image.load('pictures/menu/bees.png')

        self.SCREEN.blit(IMG_NAVOD, (0, 0))
        self.SCREEN.blit(IMG_BACK, (175, 625))
        self.SCREEN.blit(IMG_BEES, (400, 150))
        pygame.display.update()

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                    if x >= 180 and x <= 320 and y >= 630 and y <= 670:
                        Menu()
        pygame.quit()

class Highscore:
    
    def __init__(self):
        pygame.init()
        WIDTH = 500
        HEIGHT = 700
        self.SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Connect 4 Highscore")
        
        IMG_HS = pygame.image.load('pictures/menu/hs_bg.png')
        IMG_RESET = pygame.image.load('pictures/menu/reset.png')
        IMG_BACK = pygame.image.load('pictures/menu/navrat.png')

        self.SCREEN.blit(IMG_HS, (0, 0))
        self.SCREEN.blit(IMG_RESET, (75, 625))
        self.SCREEN.blit(IMG_BACK, (250, 625))

        #typ pisma a farby
        self.font = pygame.font.SysFont('Verdana', 20, True)
        BLACK = (0, 0, 0)
        WHITE = (255, 255, 255)
        GOLD = (249, 166, 2)
        
        #nacitanie info z HS.txt
        SCORE_TABLE = []
        with open('highscore.txt','r')as file:
            for row in file:
                name, score = row.split(',')
                score = int(score)
                SCORE_TABLE.append((name, score))
                
        SCORE_TABLE.sort(key=lambda x: x[1])
        #vypise HS podla poctu tahov potrebnych k vitaztstvu
        count = 1
        for name, score in SCORE_TABLE:
            if count <= 10:
                SPACE = 30 * count
                if name == 'PC':
                    rank = self.font.render(str(count)+'. miesto - '+name+' na '+str(score)+' ťahov', True, BLACK)
                    self.SCREEN.blit(rank, (75,100 + SPACE))

                elif name != '':  
                    rank = self.font.render(str(count)+'. miesto - '+name+' na '+str(score)+' ťahov', True, GOLD)
                    self.SCREEN.blit(rank, (75,100 + SPACE))

                count += 1
            else:
                pass
            
        pygame.display.update()

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                    if y >= 630 and y <= 670:
                        if x >= 80 and x <= 220:
                            #vymaze textovy subor = zmaze HS
                            with open('highscore.txt','w')as file:
                                pass
                            Highscore()
                        elif x >= 260 and x <= 400:
                            Menu()
                        
        pygame.quit()
        
        
if __name__ == '__main__':
    Menu()
